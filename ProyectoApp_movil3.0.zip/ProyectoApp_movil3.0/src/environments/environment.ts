// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

import { initializeApp } from "@angular/fire/app";

export const environment = {
	production: false,
	API_KEY: "706678183a3adde83b3c45b0eeb7cf3d",
	API_URL: "https://api.openweathermap.org/data/2.5/",
	firebase: {
		apiKey: "AIzaSyA0K55rXFSWRP5p_G3DENoTTxZRWGXwjko",

		authDomain: "tellevo-4ffad.firebaseapp.com",
	  
		projectId: "tellevo-4ffad",
	  
		storageBucket: "tellevo-4ffad.appspot.com",
	  
		messagingSenderId: "273188629778",
	  
		appId: "1:273188629778:web:1e1b7bb963ff152b6957cb",
	  
		measurementId: "G-4CN5C6EDSF"
	  
	  },
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
