import { Injectable } from '@angular/core';
import { Auth } from '@angular/fire/auth';
import { doc, docData, Firestore, setDoc } from '@angular/fire/firestore';
import { getDownloadURL, ref, Storage, uploadString } from '@angular/fire/storage';
import { StorageService } from 'src/app/services/StorageServices/storage.service';
import { Photo } from '@capacitor/camera';

@Injectable({
	providedIn: 'root'
})

export class AvatarService {
	// Variables para guardar la información de la foto de perfil y los valores del formulario.
	sName: string;
	sLast: string;
	sType: string;
	sImageUrl: string;
	sComuna: string;

	// Constructor
	constructor(
		private auth: Auth,
		private storage: Storage,
		private firestore: Firestore,
		private storageService: StorageService,
	) {
		this.getUserDataStorage();
	}

	// Función para crear primero el documento en la base de datos.
	getUserProfile() {
		const user = this.auth.currentUser;
		const userDocRef = doc(this.firestore, `users/${user?.uid}`);
		return docData(userDocRef);
	}

	// Función para actualizar la url de la foto en la base de datos.
	async uploadAvatar(cameraFile: Photo) {
		// Captura el usuario y la dirección donde desea guardar la imagen en el servidor.
		const user = this.auth.currentUser;
		const path = `uploads/${user?.uid}/profile.png`;
		const storageRef = ref(this.storage, path);

		// Se realiza un intendo para guardar la información.
		try {
			// Guarda la foto en el almacenamiento de farestorage.
			await uploadString(storageRef, cameraFile.base64String || '', 'base64');

			// Obtiene la nueva dirección creada e intenta actualizar el documento con la nueva URL de la imagen.
			const imageUrl = await getDownloadURL(storageRef);
			const userDocRef = doc(this.firestore, `users/${user?.uid}`);
			await setDoc(userDocRef, { names: this.sName, lastnames: this.sLast, imageUrl: imageUrl, typeAccount: this.sType, comuna: this.sComuna });
			return imageUrl;
		} catch (error) {
			console.log(error);
			return false;
		}
	}

	async getUserDataStorage() {
		// Capturamos la información del usuario.
		this.sName = await this.storageService.get('names');
		this.sLast = await this.storageService.get('lastnames');
		this.sType = await this.storageService.get('typeAccount');
		this.sImageUrl = await this.storageService.get('imageUrl');
		this.sComuna = await this.storageService.get('comuna');
	}
}