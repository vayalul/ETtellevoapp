import { Injectable } from '@angular/core';
import { Storage } from '@ionic/storage-angular';

@Injectable({
	providedIn: 'root'
})
export class StorageService {
	private _storage: Storage | null = null;

	// Constructor.
	constructor(private storage: Storage) {
		this.init();
	}

	async init() {
		// If using, define drivers here: await this.storage.defineDriver(/*...*/);
		const storage = await this.storage.create();
		this._storage = storage;
	}

	// Función para guardar nuevos elementos en el storage.
	async set(key: string, value: any) {
		await this._storage?.set(key, value);
	}

	// Función para consultar elementos en el storage.
	async get(key: string) {
		return await this._storage?.get(key);
	}
	
	// Función para eliminar elementos del storage.
	async remove(key: string) {
		return await this._storage?.remove(key);
	}
}
