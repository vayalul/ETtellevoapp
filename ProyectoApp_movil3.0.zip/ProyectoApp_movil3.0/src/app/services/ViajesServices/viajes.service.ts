import { Injectable } from '@angular/core';
import { Auth } from '@angular/fire/auth';
import { map } from 'rxjs/operators';
import { collection, collectionData, doc, docData, Firestore, query, setDoc, where } from '@angular/fire/firestore';
import { StorageService } from '../StorageServices/storage.service';

@Injectable({
	providedIn: 'root'
})

export class ViajesService {
	sName: string;
	sLast: string;

	// Constructor
	constructor(
		private auth: Auth,
		private firestore: Firestore,
		private storageService: StorageService
	) {
		this.getStore();
		this.getAllTravels();
	}

	async getStore() {
		// Capturamos la información del usuario.
		this.sName = await this.storageService.get('names');
		this.sLast = await this.storageService.get('lastnames');
	}

	// Función para consultar todos los viajes del cliente agregado.
	getAllTravels() {
		const user = this.auth.currentUser;
		const travelsCollection = collection(this.firestore, 'travels');

		// this method returns a stream of documents mapped to their payload and id
		const q = query(travelsCollection, where("idPasajero", "==", user?.uid));
		return collectionData(q, { idField: 'id' }).pipe(map(travels => {
			return travels;
		}));
	}

	// Función para llamar a todos los choferes disponibles de la zona en caso de que haya un viaje activo.
	getAllDrivers(comuna) {
		const travelsCollection = collection(this.firestore, 'users');
		// this method returns a stream of documents mapped to their payload and id
		const q = query(travelsCollection, where("typeAccount", "==", "Conductor"), where("comuna", "==", comuna));
		return collectionData(q, { idField: 'id' }).pipe(map(travels => {
			return travels;
		}));
	}

	// Función para consultar todos los viajes del cliente agregado.
	getAllTravelsToDrivers() {
		const user = this.auth.currentUser;
		const travelsCollection = collection(this.firestore, 'travels');

		// this method returns a stream of documents mapped to their payload and id
		const q = query(travelsCollection, where("idConductor", "==", user?.uid));
		return collectionData(q, { idField: 'id' }).pipe(map(travels => {
			return travels;
		}));
	}

	// Agregar un nuevo viaje.
	register(direccionDestino) {
		try {
			const name = this.sName + " " + this.sLast;
			const user = this.auth.currentUser; // Captura la información del usuario registrado.
			const document = doc(collection(this.firestore, 'travels'));
			setDoc(document, { direccionDestino: direccionDestino, estatus: "Pendiente", fecha: new Date().toString(), idConductor: "", nombreChofer: "", idPasajero: user?.uid, nombrePasajero: name }); // Actualiza la informaicón con los datos ingresados.
			return true;
		} catch (error) {
			console.log(error);
			return false;
		}
	}

	// Actualizar el estatus de los viajes.
	updateTravel(travel, status) {
		try {
			const userDocRef = doc(this.firestore, `travels/${travel?.id}`); // Define y toma como referencia un nuevo documento para los datos del usuario.
			setDoc(userDocRef, { direccionDestino: travel.direccionDestino, fecha: travel.fecha, idPasajero: travel.idPasajero, nombrePasajero: travel.nombrePasajero, estatus: status, idConductor: travel.idConductor, nombreChofer: travel.nombreChofer });
			return true;
		} catch (error) {
			console.log(error);
			return false;
		}
	}

	// Actualizar el chofer de los viajes.
	updateTravelsD(travel, driverID, driverName) {
		try {
			const userDocRef = doc(this.firestore, `travels/${travel?.id}`); // Define y toma como referencia un nuevo documento para los datos del usuario.
			setDoc(userDocRef, { direccionDestino: travel.direccionDestino, fecha: travel.fecha, idPasajero: travel.idPasajero, nombrePasajero: travel.nombrePasajero, estatus: travel.estatus, idConductor: driverID, nombreChofer: driverName });
			return true;
		} catch (error) {
			console.log(error);
			return false;
		}
	}

	// Función para que chofer rechazar o aceptar el viaje
	updateTravelsToDriver(travel, status) {
		try {
			// Capturamos los adtos del chofer y establecemos si permanecen o se borran si el viaje es aceptado o denegado.
			const newIDChofer = status != 'Denegar' ? travel.idConductor : '';
			const newNombreChofer = status != 'Denegar' ? travel.nombreChofer : '';
			const newStatusTravel = status != 'Denegar' ? status : travel.estatus;
			
			// Realizamos la actualización en la base de datos.
			const userDocRef = doc(this.firestore, `travels/${travel?.id}`); // Define y toma como referencia un nuevo documento para los datos del usuario.
			setDoc(userDocRef, { direccionDestino: travel.direccionDestino, fecha: travel.fecha, idPasajero: travel.idPasajero, nombrePasajero: travel.nombrePasajero, estatus: newStatusTravel, idConductor: newIDChofer, nombreChofer: newNombreChofer });
			return true;
		} catch (error) {
			console.log(error);
			return false;
		}
	}
}
