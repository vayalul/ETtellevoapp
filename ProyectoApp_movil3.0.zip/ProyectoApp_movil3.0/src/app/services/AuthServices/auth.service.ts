import { Injectable } from '@angular/core';
import { collection, collectionData, doc, docData, docSnapshots, Firestore, setDoc } from '@angular/fire/firestore';
import { map } from 'rxjs/operators';
import { StorageService } from 'src/app/services/StorageServices/storage.service';

import { Auth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut } from '@angular/fire/auth';

@Injectable({
	providedIn: 'root'
  })

export class AuthService {
	// Variables para guardar la información de la foto de perfil y los valores del formulario.
	sName: string;
	sLast: string;
	sType: string;
	sImageUrl: string;

	// Constructor
	constructor(
		private auth: Auth,
		private firestore: Firestore,
		private storageService: StorageService,
	) {
		this.getUserDataStorage();
	}

	async getUserDataStorage() {
		// Capturamos la información del usuario.
		this.sName = await this.storageService.get('names');
		this.sLast = await this.storageService.get('lastnames');
		this.sType = await this.storageService.get('typeAccount');
		this.sImageUrl = await this.storageService.get('imageUrl');
	}

	// Función para crear primero el documento en la base de datos.
	getUserData() {
		const user = this.auth.currentUser;
		const userDocRef = doc(this.firestore, `users/${user?.uid}`);
		return docData(userDocRef);
	}

	// Función para registrar un nuevo usuario en la base de datos.
	async register(email: string, password: string) {
		try {
			return await createUserWithEmailAndPassword(this.auth, email, password);
		} catch (error) {
			return null;
		}
	}

	// Función para guardar un nuevo documento con los datos del usuario en la base de datos.
	async registerUserData(names: string, lastnames: string, typeAccount: string, comuna: string) {
		try {
			const user = this.auth.currentUser; // Captura la información del usuario registrado.
			const userDocRef = doc(this.firestore, `users/${user?.uid}`); // Define y toma como referencia un nuevo documento para los datos del usuario.
			setDoc(userDocRef, { names: names, lastnames: lastnames, typeAccount: typeAccount, imageUrl: "", comuna: comuna }); // Actualiza la informaicón con los datos ingresados.
			return true;
		} catch (error) {
			console.log(error);
			return false;
		}
	}

	// Función para autenticación en la base de datos.
	async login(email: string, password: string) {
		try {
			return await signInWithEmailAndPassword(this.auth, email, password);
		} catch (error) {
			return null;
		}
	}

	// Función para guardar los datos del usuario en el Storage.
	loginUserData() {
		const user = this.auth.currentUser;
		// const document = doc(this.firestore,  `users/${user?.uid}`);

		const document = doc(this.firestore, `users/${user?.uid}`);
		return docSnapshots(document).pipe(map(doc => {
			const id = doc.id;
			const data = doc.data();
			return { id, ...data };
		}));
	}

	// Función para obtener los datos del usuario.
	async getUserProfile() {
		return await this.auth.currentUser;
	}

	// Función para cerrar sesión.
	async logout() {
		return signOut(this.auth);
	}
}
