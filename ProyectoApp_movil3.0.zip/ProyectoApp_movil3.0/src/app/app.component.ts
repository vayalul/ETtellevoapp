import { Component } from '@angular/core';
import { StorageService } from './services/StorageServices/storage.service';

@Component({
	selector: 'app-root',
	templateUrl: 'app.component.html',
	styleUrls: ['app.component.scss'],
})

export class AppComponent {
	public appPages = [
		{ title: 'Inicio', url: 'inicio', icon: 'home' },
		{ title: 'Perfil', url: 'perfil', icon: 'person-circle' },
		{ title: 'Viajes', url: 'viajes', icon: 'car-sport' },
		{ title: 'Clima', url: 'clima', icon: 'cloudy-night' },
		{ title: 'Conversor Monedas', url: 'conversor', icon: 'cash' },
		{ title: 'Contacto', url: 'contacto', icon: 'chatbox-ellipses' },
		{ title: 'Acerca de', url: 'nosotros', icon: 'finger-print' },
		{ title: 'Sesión', url: 'home', icon: 'log-in' },
	];

	constructor(
		public storageService: StorageService
	) { }

	async ngOnInit() {
		this.storageService.init();
	}
}
