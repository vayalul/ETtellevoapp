import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AlertController, LoadingController } from '@ionic/angular';
import { ViajesService } from 'src/app/services/ViajesServices/viajes.service';
import Comunas from 'src/app/pages/comunas';

@Component({
	selector: 'app-nuevo-viaje',
	templateUrl: './nuevo-viaje.page.html',
	styleUrls: ['./nuevo-viaje.page.scss'],
})

export class NuevoViajePage implements OnInit {
	// Variable para almacenar los valores del formulario.
	travelPending: boolean = false;
	travelFrom!: FormGroup;
	comunas = Comunas;

	// Constructor
	constructor(
		private formBuilder: FormBuilder,
		private alertCtrl: AlertController,
		private loadingCtrl: LoadingController,
		private viajesService: ViajesService,
		private router: Router,
	) { }

	ngOnInit() {
		this.createForm();
		this.loadTravels();
	}

	// Función que espera los viajes realizados para cargarlos en la vista.
	async loadTravels() {
		await this.viajesService.getAllTravels().subscribe(respuesta => {
			// Vamos a recorrer los viajes revisando cual esta pendiente y necesita chofer.
			for (let i = 0; i < respuesta.length; i++) {
				// Si hay un viaje pendiente, no debe permitir que cree nuevas hasta terminar la que se encuentra activa.
				if (respuesta[i].status != "Terminado" && respuesta[i].status != "Cancelado" && respuesta[i].status != undefined) this.travelPending = true;
			}
		});
	}

	get direccionDestino() {
		return this.travelFrom?.get('direccionDestino');
	}

	// Construir los campos del formulario y agregar validaciones.
	createForm() {
		this.travelFrom = this.formBuilder.group({
			direccionDestino: ['', [Validators.required]]
		});
	}

	// Función para realizar un nuevo registro en la base de datos.
	async registerTravel() {
		// Creamos una pequeña ventana de carga mientras se realiza la consulta a la base de datos.
		const loading = await this.loadingCtrl.create();
		await loading.present();

		// Se realiza la consulta a Firebase para realizar un nuevo registro de usuario.
		const travel = await this.viajesService.register(this.travelFrom.value.direccionDestino);

		// Si la consulta se ejecuto correctamente, procede a dar la bienvenida y llevar al inicio.
		if (travel) {
			// Oculta la venta de carga una vez termine de ejecturarse la consulta a la base de datos.
			await loading.dismiss();

			// Mandamos mensaje de exito y redirecciónamos a los viajes.
			this.alertPresent('Registro Exitoso', 'El viaje se registro exitosamente');
			this.router.navigateByUrl('/viajes');
		} else {
			this.alertPresent('Registro fallido', 'Ocurrió un error al registrar');
		}
	}

	// Mensaje de alerta personalizado.
	async alertPresent(header: string, message: string) {
		const alert = await this.alertCtrl.create({
			header: header,
			message: message,
			buttons: ['OK'],
		});
		alert.present();
	}
}
