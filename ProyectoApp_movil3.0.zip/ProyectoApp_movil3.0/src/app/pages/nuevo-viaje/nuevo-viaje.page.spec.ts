import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { AlertController } from '@ionic/angular';
import { LoadingController } from '@ionic/angular';
import { ViajesService } from 'src/app/services/ViajesServices/viajes.service';
import { Comunas } from 'src/app/pages/comunas';
import { NuevoViajePage } from './nuevo-viaje.page';

describe('NuevoViajePage', () => {
  let component: NuevoViajePage;
  let fixture: ComponentFixture<NuevoViajePage>;

  beforeEach(() => {
    const routerStub = () => ({ navigateByUrl: string => ({}) });
    const formBuilderStub = () => ({ group: object => ({}) });
    const alertControllerStub = () => ({
      create: object => ({ present: () => ({}) })
    });
    const loadingControllerStub = () => ({
      create: () => ({ present: () => ({}), dismiss: () => ({}) })
    });
    const viajesServiceStub = () => ({
      getAllTravels: () => ({ subscribe: f => f({}) }),
      register: direccionDestino => ({})
    });
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [NuevoViajePage],
      providers: [
        { provide: Router, useFactory: routerStub },
        { provide: FormBuilder, useFactory: formBuilderStub },
        { provide: AlertController, useFactory: alertControllerStub },
        { provide: LoadingController, useFactory: loadingControllerStub },
        { provide: ViajesService, useFactory: viajesServiceStub }
      ]
    });
    fixture = TestBed.createComponent(NuevoViajePage);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  it(`travelPending has default value`, () => {
    expect(component.travelPending).toEqual(false);
  });

  it(`comunas has default value`, () => {
    expect(component.comunas).toEqual(Comunas);
  });

  describe('ngOnInit', () => {
    it('makes expected calls', () => {
      spyOn(component, 'createForm').and.callThrough();
      spyOn(component, 'loadTravels').and.callThrough();
      component.ngOnInit();
      expect(component.createForm).toHaveBeenCalled();
      expect(component.loadTravels).toHaveBeenCalled();
    });
  });

  describe('loadTravels', () => {
    it('makes expected calls', () => {
      const viajesServiceStub: ViajesService = fixture.debugElement.injector.get(
        ViajesService
      );
      spyOn(viajesServiceStub, 'getAllTravels').and.callThrough();
      component.loadTravels();
      expect(viajesServiceStub.getAllTravels).toHaveBeenCalled();
    });
  });

  describe('createForm', () => {
    it('makes expected calls', () => {
      const formBuilderStub: FormBuilder = fixture.debugElement.injector.get(
        FormBuilder
      );
      spyOn(formBuilderStub, 'group').and.callThrough();
      component.createForm();
      expect(formBuilderStub.group).toHaveBeenCalled();
    });
  });

  describe('registerTravel', () => {
    it('makes expected calls', () => {
      const routerStub: Router = fixture.debugElement.injector.get(Router);
      const loadingControllerStub: LoadingController = fixture.debugElement.injector.get(
        LoadingController
      );
      const viajesServiceStub: ViajesService = fixture.debugElement.injector.get(
        ViajesService
      );
      spyOn(component, 'alertPresent').and.callThrough();
      spyOn(routerStub, 'navigateByUrl').and.callThrough();
      spyOn(loadingControllerStub, 'create').and.callThrough();
      spyOn(viajesServiceStub, 'register').and.callThrough();
      component.registerTravel();
      expect(component.alertPresent).toHaveBeenCalled();
      expect(routerStub.navigateByUrl).toHaveBeenCalled();
      expect(loadingControllerStub.create).toHaveBeenCalled();
      expect(viajesServiceStub.register).toHaveBeenCalled();
    });
  });
});
