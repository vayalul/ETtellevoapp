import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { AlertController, LoadingController } from '@ionic/angular';
import { ViajesService } from 'src/app/services/ViajesServices/viajes.service';
import { StorageService } from 'src/app/services/StorageServices/storage.service';
import { PickerController } from '@ionic/angular';

@Component({
	selector: 'app-viajes',
	templateUrl: './viajes.page.html',
	styleUrls: ['./viajes.page.scss'],
})

export class ViajesPage implements OnInit {
	Travels = [];
	drivers = [];
	Request = [];
	travelPending: boolean = false;
	direccionDestino: string;
	sType: string;

	// Constructor.
	constructor(
		private alertCtrl: AlertController,
		private pickerCtrl: PickerController,
		private loadingCtrl: LoadingController,
		private storageService: StorageService,
		private viajesService: ViajesService,
		private router: Router,
	) { }

	async ngOnInit() {
		this.sType = await this.storageService.get('typeAccount');
		this.sType == 'Conductor' ? this.loadRequest() : this.loadTravels();
	}

	// Función que espera los viajes realizados para cargarlos en la vista.
	async loadTravels() {
		await this.viajesService.getAllTravels().subscribe(respuesta => {
			this.Travels = respuesta;

			// Vamos a recorrer los viajes revisando cual esta pendiente y necesita chofer.
			for (let i = 0; i < respuesta.length; i++) {
				// Si hay un viaje pendiente, no debe permitir que cree nuevas hasta terminar la que se encuentra activa.
				if (respuesta[i].estatus != "Terminado" && respuesta[i].estatus != "Cancelado" && respuesta[i].estatus != undefined) {
					this.travelPending = true;
					console.log(this.travelPending);

					// Verificamos si hay alguna que no tenga chofer y en tal caso, buscamos los choferes que vayan a la sona de destino.
					if (respuesta[i].nombreChofer == "") {
						// Capturamos la comuna a la que debe buscar choferes disponibles.
						this.direccionDestino = respuesta[i].direccionDestino;

						// realizamos una consulta a la base de datos para traer todos los choferes disponibles.
						this.viajesService.getAllDrivers(this.direccionDestino).subscribe(respuesta2 => {
							for (let j = 0; j < respuesta2.length; j++) {
								this.drivers.push({ text: respuesta2[j].names + " " + respuesta2[j].lastnames, value: respuesta2[j].id });
							}
						})
					}
				}
			}
		});
	}

	// Función para consultar todas las solicitudes de de viajes agregas.
	async loadRequest() {
		await this.viajesService.getAllTravelsToDrivers().subscribe(respuesta => {
			this.Request = respuesta;
		});
	}

	// Actualizar el estatus de un viaje pendiente.
	async updateTravels(travel, status) {
		// Creamos una pequeña ventana de carga mientras se realiza la consulta a la base de datos.
		const loading = await this.loadingCtrl.create();
		await loading.present();

		const viaje = await this.viajesService.updateTravel(travel, status);
		// Si la consulta se ejecuto correctamente, procede a dar la bienvenida y llevar al inicio.
		if (viaje) {
			// Oculta la venta de carga una vez termine de ejecturarse la consulta a la base de datos.
			await loading.dismiss();

			// Mandamos mensaje de bienvenida y redirecciónamos al inicio.
			this.alertPresent('Actualización Exitosa', 'Estatus actualizado');
			this.router.navigateByUrl('/viajes');
		} else {
			this.alertPresent('Actualización fallida', 'Error al actualizar');
		}
	}

	// Actualizar el chofer de un viaje pendiente.
	async updateTravelsD(travel, driverID, driverName) {
		// Creamos una pequeña ventana de carga mientras se realiza la consulta a la base de datos.
		const loading = await this.loadingCtrl.create();
		await loading.present();

		const viaje = await this.viajesService.updateTravelsD(travel, driverID, driverName);
		// Si la consulta se ejecuto correctamente, procede a dar la bienvenida y llevar al inicio.
		if (viaje) {
			// Oculta la venta de carga una vez termine de ejecturarse la consulta a la base de datos.
			await loading.dismiss();

			// Mandamos mensaje de bienvenida y redirecciónamos al inicio.
			this.alertPresent('Actualización Exitosa', 'Chofer actualizado');
			this.router.navigateByUrl('/viajes');
		} else {
			this.alertPresent('Actualización fallida', 'Error al actualizar');
		}
	}

	// Aceptar la solicitud de viaje por parte del chofer
	async acceptTravel (travel, status) {
		// Creamos una pequeña ventana de carga mientras se realiza la consulta a la base de datos.
		const loading = await this.loadingCtrl.create();
		await loading.present();

		const viaje = await this.viajesService.updateTravelsToDriver(travel, status);
		// Si la consulta se ejecuto correctamente, procede a dar la bienvenida y llevar al inicio.
		if (viaje) {
			// Oculta la venta de carga una vez termine de ejecturarse la consulta a la base de datos.
			await loading.dismiss();

			// Mandamos mensaje de bienvenida y redirecciónamos al inicio.
			this.alertPresent('Actualización Exitosa', status == 'denegar' ? 'Viaje negado' : 'Viaje aceptado');
			this.router.navigateByUrl('/viajes');
		} else {
			this.alertPresent('Actualización fallida', 'Error al actualizar');
		}
	}

	// Botón de opciones de los estatus de los viajes activos.
	async pickerStatus(travel) {
		const picker = await this.pickerCtrl.create({
			columns: [
				{
					name: 'estatus',
					options: [
						{ text: 'Pendiente', value: 'Pendiente', },
						{ text: 'Aceptado', value: 'Aceptado', },
						{ text: 'Cancelado', value: 'Cancelado', },
						{ text: 'Terminado', value: 'Terminado', },
					],
				},
			],
			buttons: [
				{ text: 'Cancelar', role: 'cancel', },
				{ text: 'Confirmar', handler: (value) => { this.updateTravels(travel, value.estatus.value) } },
			],
		});
		await picker.present();
	}

	// Botón de opciones de los choferes activos de la zona.
	async pickerDriver(travel) {
		const picker = await this.pickerCtrl.create({
			columns: [
				{
					name: 'drivers',
					options: this.drivers,
				},
			],
			buttons: [
				{ text: 'Cancelar', role: 'cancel', },
				{ text: 'Confirmar', handler: (value) => { this.updateTravelsD(travel, value.drivers.value, value.drivers.text) } },
			],
		});
		await picker.present();
	}

	// Botón de opciones para que el chofer acepte o niegue la carrera.
	async pickerAccept (travel) {
		const picker = await this.pickerCtrl.create({
			columns: [
				{
					name: 'estatus',
					options: [
						{ text: 'Aceptar', value: 'Aceptado', },
						{ text: 'Degenar', value: 'Denegar', },
					],
				},
			],
			buttons: [
				{ text: 'Cancelar', role: 'cancel', },
				{ text: 'Confirmar', handler: (value) => { this.acceptTravel(travel, value.estatus.value) } },
			],
		});
		await picker.present();
	}

	// Mensaje de alerta personalizado.
	async alertPresent(header: string, message: string) {
		const alert = await this.alertCtrl.create({
			header: header,
			message: message,
			buttons: ['OK'],
		});
		alert.present();
	}
}
