import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { LoadingController } from '@ionic/angular';
import { ViajesService } from 'src/app/services/ViajesServices/viajes.service';
import { StorageService } from 'src/app/services/StorageServices/storage.service';
import { PickerController } from '@ionic/angular';
import { ViajesPage } from './viajes.page';

describe('ViajesPage', () => {
  let component: ViajesPage;
  let fixture: ComponentFixture<ViajesPage>;

  beforeEach(() => {
    const routerStub = () => ({ navigateByUrl: string => ({}) });
    const alertControllerStub = () => ({
      create: object => ({ present: () => ({}) })
    });
    const loadingControllerStub = () => ({
      create: () => ({ present: () => ({}), dismiss: () => ({}) })
    });
    const viajesServiceStub = () => ({
      getAllTravels: () => ({ subscribe: f => f({}) }),
      getAllDrivers: direccionDestino => ({ subscribe: f => f({}) }),
      getAllTravelsToDrivers: () => ({ subscribe: f => f({}) }),
      updateTravel: (travel, status) => ({}),
      updateTravelsD: (travel, driverID, driverName) => ({}),
      updateTravelsToDriver: (travel, status) => ({})
    });
    const storageServiceStub = () => ({ get: string => ({}) });
    const pickerControllerStub = () => ({
      create: object => ({ present: () => ({}) })
    });
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [ViajesPage],
      providers: [
        { provide: Router, useFactory: routerStub },
        { provide: AlertController, useFactory: alertControllerStub },
        { provide: LoadingController, useFactory: loadingControllerStub },
        { provide: ViajesService, useFactory: viajesServiceStub },
        { provide: StorageService, useFactory: storageServiceStub },
        { provide: PickerController, useFactory: pickerControllerStub }
      ]
    });
    fixture = TestBed.createComponent(ViajesPage);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  it(`Travels has default value`, () => {
    expect(component.Travels).toEqual([]);
  });

  it(`drivers has default value`, () => {
    expect(component.drivers).toEqual([]);
  });

  it(`Request has default value`, () => {
    expect(component.Request).toEqual([]);
  });

  it(`travelPending has default value`, () => {
    expect(component.travelPending).toEqual(false);
  });

  describe('loadTravels', () => {
    it('makes expected calls', () => {
      const viajesServiceStub: ViajesService = fixture.debugElement.injector.get(
        ViajesService
      );
      spyOn(viajesServiceStub, 'getAllTravels').and.callThrough();
      spyOn(viajesServiceStub, 'getAllDrivers').and.callThrough();
      component.loadTravels();
      expect(viajesServiceStub.getAllTravels).toHaveBeenCalled();
      expect(viajesServiceStub.getAllDrivers).toHaveBeenCalled();
    });
  });

  describe('loadRequest', () => {
    it('makes expected calls', () => {
      const viajesServiceStub: ViajesService = fixture.debugElement.injector.get(
        ViajesService
      );
      spyOn(viajesServiceStub, 'getAllTravelsToDrivers').and.callThrough();
      component.loadRequest();
      expect(viajesServiceStub.getAllTravelsToDrivers).toHaveBeenCalled();
    });
  });
});
