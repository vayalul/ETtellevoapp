export class Viajes {
	id: string;
	direccionDestino: string;
	idConductor: string;
	idPasajero: string;
	estatus: string;
}