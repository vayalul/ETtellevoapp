import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AlertController, LoadingController } from '@ionic/angular';
import { AuthService } from 'src/app/services/AuthServices/auth.service';
import { StorageService } from 'src/app/services/StorageServices/storage.service';
import Comunas from 'src/app/pages/comunas';

@Component({
	selector: 'app-registrarse',
	templateUrl: './registrarse.page.html',
	styleUrls: ['./registrarse.page.scss'],
})

export class RegistrarsePage implements OnInit {
	// Variable para almacenar los valores del formulario.
	credentials!: FormGroup;
	comunas = Comunas;

	// Constructor
	constructor(
		private authService: AuthService,
		private formBuilder: FormBuilder,
		private alertCtrl: AlertController,
		private loadingCtrl: LoadingController,
		private storageService: StorageService,
		private router: Router
	) { }

	async ngOnInit() {
		this.createForm();
	}

	get names() {
		return this.credentials?.get('names');
	}

	get lastnames() {
		return this.credentials?.get('lastnames');
	}

	get comunas_() {
		return this.credentials?.get('comunas_');
	}

	get email() {
		return this.credentials?.get('email');
	}

	get password() {
		return this.credentials?.get('password');
	}

	get typeAccount() {
		return this.credentials?.get('typeAccount');
	}

	// Construir los campos del formulario y agregar validaciones.
	createForm() {
		this.credentials = this.formBuilder.group({
			names: ['', [Validators.required]],
			lastnames: ['', [Validators.required]],
			comunas_: ['', [Validators.required]],
			email: ['', [Validators.required, Validators.email]],
			password: ['', [Validators.required, Validators.minLength(6)]],
			typeAccount: ['', [Validators.required]],
		});
	}

	// Función para realizar un nuevo registro en la base de datos.
	async register() {
		// Creamos una pequeña ventana de carga mientras se realiza la consulta a la base de datos.
		const loading = await this.loadingCtrl.create();
		await loading.present();

		// Se realiza la consulta a Firebase para realizar un nuevo registro de usuario.
		const user = await this.authService.register(this.credentials.value.email, this.credentials.value.password);

		// Si la consulta se ejecuto correctamente, procede a dar la bienvenida y llevar al inicio.
		if (user) {
			const newDoc = await this.authService.registerUserData(this.credentials.value.names, this.credentials.value.lastnames, this.credentials.value.typeAccount, this.credentials.value.comunas_);
			// Oculta la venta de carga una vez termine de ejecturarse la consulta a la base de datos.
			await loading.dismiss();

			// Si la consulta se ejecuto correctamente, procede a dar la bienvenida y llevar al inicio.
			if (newDoc) {
				// Guardamos los datos en el storage.
				this.storageService.set('imageUrl', '');
				this.storageService.set('names', this.credentials.value.names);
				this.storageService.set('lastnames', this.credentials.value.lastnames);
				this.storageService.set('email', this.credentials.value.email);
				this.storageService.set('typeAccount', this.credentials.value.typeAccount);
				this.storageService.set('comuna', this.credentials.value.comunas_);
				
				// Mandamos mensaje de bienvenida y redirecciónamos al inicio.
				this.alertPresent('Registro Exitoso', 'Bienvenido');
				this.router.navigateByUrl('/inicio');
			} else {
				this.alertPresent('Registro fallido', 'Ingreso incorrecto');
			}
		} else {
			// Oculta la venta de carga una vez termine de ejecturarse la consulta a la base de datos.
			await loading.dismiss();

			this.alertPresent('Registro fallido', 'Ingreso incorrecto');
		}
	}

	// Mensaje de alerta personalizado.
	async alertPresent(header: string, message: string) {
		const alert = await this.alertCtrl.create({
			header: header,
			message: message,
			buttons: ['OK'],
		});
		alert.present();
	}
}
