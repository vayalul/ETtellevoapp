import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { AlertController } from '@ionic/angular';
import { LoadingController } from '@ionic/angular';
import { AuthService } from 'src/app/services/AuthServices/auth.service';
import { StorageService } from 'src/app/services/StorageServices/storage.service';
import  Comunas from 'src/app/pages/comunas';
import { RegistrarsePage } from './registrarse.page';

describe('RegistrarsePage', () => {
  let component: RegistrarsePage;
  let fixture: ComponentFixture<RegistrarsePage>;

  beforeEach(() => {
    const routerStub = () => ({ navigateByUrl: string => ({}) });
    const formBuilderStub = () => ({ group: object => ({}) });
    const alertControllerStub = () => ({
      create: object => ({ present: () => ({}) })
    });
    const loadingControllerStub = () => ({
      create: () => ({ present: () => ({}), dismiss: () => ({}) })
    });
    const authServiceStub = () => ({
      register: (email, password) => ({}),
      registerUserData: (names, lastnames, typeAccount, comunas_) => ({})
    });
    const storageServiceStub = () => ({ set: (string, string1) => ({}) });
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [RegistrarsePage],
      providers: [
        { provide: Router, useFactory: routerStub },
        { provide: FormBuilder, useFactory: formBuilderStub },
        { provide: AlertController, useFactory: alertControllerStub },
        { provide: LoadingController, useFactory: loadingControllerStub },
        { provide: AuthService, useFactory: authServiceStub },
        { provide: StorageService, useFactory: storageServiceStub }
      ]
    });
    fixture = TestBed.createComponent(RegistrarsePage);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  it(`comunas has default value`, () => {
    expect(component.comunas).toEqual(Comunas);
  });

  describe('createForm', () => {
    it('makes expected calls', () => {
      const formBuilderStub: FormBuilder = fixture.debugElement.injector.get(
        FormBuilder
      );
      spyOn(formBuilderStub, 'group').and.callThrough();
      component.createForm();
      expect(formBuilderStub.group).toHaveBeenCalled();
    });
  });

  describe('register', () => {
    it('makes expected calls', () => {
      const routerStub: Router = fixture.debugElement.injector.get(Router);
      const loadingControllerStub: LoadingController = fixture.debugElement.injector.get(
        LoadingController
      );
      const authServiceStub: AuthService = fixture.debugElement.injector.get(
        AuthService
      );
      const storageServiceStub: StorageService = fixture.debugElement.injector.get(
        StorageService
      );
      spyOn(component, 'alertPresent').and.callThrough();
      spyOn(routerStub, 'navigateByUrl').and.callThrough();
      spyOn(loadingControllerStub, 'create').and.callThrough();
      spyOn(authServiceStub, 'register').and.callThrough();
      spyOn(authServiceStub, 'registerUserData').and.callThrough();
      spyOn(storageServiceStub, 'set').and.callThrough();
      component.register();
      expect(component.alertPresent).toHaveBeenCalled();
      expect(routerStub.navigateByUrl).toHaveBeenCalled();
      expect(loadingControllerStub.create).toHaveBeenCalled();
      expect(authServiceStub.register).toHaveBeenCalled();
      expect(authServiceStub.registerUserData).toHaveBeenCalled();
      expect(storageServiceStub.set).toHaveBeenCalled();
    });
  });
});
