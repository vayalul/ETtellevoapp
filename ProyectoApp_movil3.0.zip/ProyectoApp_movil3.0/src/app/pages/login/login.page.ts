import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AlertController, LoadingController } from '@ionic/angular';
import { AuthService } from 'src/app/services/AuthServices/auth.service';
import { StorageService } from 'src/app/services/StorageServices/storage.service';

@Component({
	selector: 'app-login',
	templateUrl: './login.page.html',
	styleUrls: ['./login.page.scss'],
})

export class LoginPage implements OnInit {
	// Variable para almacenar los valores del formulario.
	profile: any = null;
	credentials!: FormGroup;
	sName: string;
	sLast: string;
	sEmail: string;
	sType: string;
	sImageUrl: string;
	cots: number = 0;

	// Constructor
	constructor(
		private authService: AuthService,
		private formBuilder: FormBuilder,
		private alertCtrl: AlertController,
		private loadingCtrl: LoadingController,
		private storageService: StorageService,
		private router: Router
	) {
	}

	async ngOnInit() {
		this.createForm();
		// Capturamos la información del usuario.
		this.sName = await this.storageService.get('names');
		this.sLast = await this.storageService.get('lastnames');
		this.sEmail = await this.storageService.get('email');
		this.sType = await this.storageService.get('typeAccount');
		this.sImageUrl = await this.storageService.get('imageUrl');
	}

	get email() {
		return this.credentials?.get('email');
	}

	get password() {
		return this.credentials?.get('password');
	}

	// Construir los campos del formulario y agregar validaciones.
	createForm() {
		this.credentials = this.formBuilder.group({
			email: ['', [Validators.required, Validators.email]],
			password: ['', [Validators.required, Validators.minLength(6)]],
		});
	}

	// Función para realizar un nueva sesión en la base de datos.
	async login() {
		// Creamos una pequeña ventana de carga mientras se realiza la consulta a la base de datos.
		const loading = await this.loadingCtrl.create();
		await loading.present();

		// Se realiza la consulta a Firebase para realizar.
		const user = await this.authService.login(this.credentials.value.email, this.credentials.value.password);

		// Si la consulta se ejecuto correctamente, procede a dar la bienvenida y llevar al inicio.
		if (user) {
			// Guardamos los datos en el storage.
			this.storageService.set('email', this.credentials.value.email);

			// Consultamos los datos del usuario logueado.
			await this.loadLogin(loading);
		} else {
			this.alertPresent('Ingreso fallido', 'Correo electrónico o contraseña incorrecta');
		}
	}

	// Función que espera los viajes realizados para cargarlos en la vista.
	async loadLogin(loading) {
		await this.authService.loginUserData().subscribe(respuesta => {
			this.saveData(respuesta, loading);
		});
	}

	saveData(data, loading) {
		// Guardamos los datos en el storage.
		this.storageService.set('imageUrl', data.imageUrl);
		this.storageService.set('names', data.names);
		this.storageService.set('lastnames', data.lastnames);
		this.storageService.set('typeAccount', data.typeAccount);
		this.storageService.set('comuna', data.comuna);

		this.cots++;
		if (this.cots == 1) {
			// Oculta la venta de carga una vez termine de ejecturarse la consulta a la base de datos.
			loading.dismiss();

			// Mandamos mensaje de bienvenida y redirecciónamos al inicio.
			this.alertPresent('Ingreso Exitoso', 'Bienvenido');
			this.router.navigateByUrl('/inicio');
		}
	}

	// Mensaje de alerta personalizado.
	async alertPresent(header: string, message: string) {
		const alert = await this.alertCtrl.create({
			header: header,
			message: message,
			buttons: ['OK'],
		});
		alert.present();
	}
}