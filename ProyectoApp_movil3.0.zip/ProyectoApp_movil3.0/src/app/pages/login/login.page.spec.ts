import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { AlertController } from '@ionic/angular';
import { LoadingController } from '@ionic/angular';
import { AuthService } from 'src/app/services/AuthServices/auth.service';
import { StorageService } from 'src/app/services/StorageServices/storage.service';
import { LoginPage } from './login.page';

describe('LoginPage', () => {
  let component: LoginPage;
  let fixture: ComponentFixture<LoginPage>;

  beforeEach(() => {
    const routerStub = () => ({ navigateByUrl: string => ({}) });
    const formBuilderStub = () => ({ group: object => ({}) });
    const alertControllerStub = () => ({
      create: object => ({ present: () => ({}) })
    });
    const loadingControllerStub = () => ({
      create: () => ({ present: () => ({}) })
    });
    const authServiceStub = () => ({
      login: (email, password) => ({}),
      loginUserData: () => ({ subscribe: f => f({}) })
    });
    const storageServiceStub = () => ({
      get: string => ({}),
      set: (string, email) => ({})
    });
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [LoginPage],
      providers: [
        { provide: Router, useFactory: routerStub },
        { provide: FormBuilder, useFactory: formBuilderStub },
        { provide: AlertController, useFactory: alertControllerStub },
        { provide: LoadingController, useFactory: loadingControllerStub },
        { provide: AuthService, useFactory: authServiceStub },
        { provide: StorageService, useFactory: storageServiceStub }
      ]
    });
    fixture = TestBed.createComponent(LoginPage);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  it(`cots has default value`, () => {
    expect(component.cots).toEqual(0);
  });

  describe('createForm', () => {
    it('makes expected calls', () => {
      const formBuilderStub: FormBuilder = fixture.debugElement.injector.get(
        FormBuilder
      );
      spyOn(formBuilderStub, 'group').and.callThrough();
      component.createForm();
      expect(formBuilderStub.group).toHaveBeenCalled();
    });
  });

  describe('login', () => {
    it('makes expected calls', () => {
      const loadingControllerStub: LoadingController = fixture.debugElement.injector.get(
        LoadingController
      );
      const authServiceStub: AuthService = fixture.debugElement.injector.get(
        AuthService
      );
      const storageServiceStub: StorageService = fixture.debugElement.injector.get(
        StorageService
      );
      spyOn(component, 'loadLogin').and.callThrough();
      spyOn(component, 'alertPresent').and.callThrough();
      spyOn(loadingControllerStub, 'create').and.callThrough();
      spyOn(authServiceStub, 'login').and.callThrough();
      spyOn(storageServiceStub, 'set').and.callThrough();
      component.login();
      expect(component.loadLogin).toHaveBeenCalled();
      expect(component.alertPresent).toHaveBeenCalled();
      expect(loadingControllerStub.create).toHaveBeenCalled();
      expect(authServiceStub.login).toHaveBeenCalled();
      expect(storageServiceStub.set).toHaveBeenCalled();
    });
  });
});
