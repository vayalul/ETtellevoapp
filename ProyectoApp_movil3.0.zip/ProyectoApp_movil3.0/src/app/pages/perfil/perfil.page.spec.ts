import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { LoadingController } from '@ionic/angular';
import { AuthService } from 'src/app/services/AuthServices/auth.service';
import { AvatarService } from 'src/app/services/AvatarServices/avatar.service';
import { StorageService } from 'src/app/services/StorageServices/storage.service';
import { PerfilPage } from './perfil.page';

describe('PerfilPage', () => {
  let component: PerfilPage;
  let fixture: ComponentFixture<PerfilPage>;

  beforeEach(() => {
    const routerStub = () => ({ navigateByUrl: string => ({}) });
    const alertControllerStub = () => ({
      create: object => ({ present: () => ({}) })
    });
    const loadingControllerStub = () => ({
      create: () => ({ present: () => ({}), dismiss: () => ({}) })
    });
    const authServiceStub = () => ({});
    const avatarServiceStub = () => ({
      getUserProfile: () => ({ subscribe: f => f({}) }),
      uploadAvatar: avatar => ({})
    });
    const storageServiceStub = () => ({
      get: string => ({}),
      set: (string, names) => ({})
    });
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [PerfilPage],
      providers: [
        { provide: Router, useFactory: routerStub },
        { provide: AlertController, useFactory: alertControllerStub },
        { provide: LoadingController, useFactory: loadingControllerStub },
        { provide: AuthService, useFactory: authServiceStub },
        { provide: AvatarService, useFactory: avatarServiceStub },
        { provide: StorageService, useFactory: storageServiceStub }
      ]
    });
    spyOn(PerfilPage.prototype, 'cargarAvatar');
    fixture = TestBed.createComponent(PerfilPage);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  describe('constructor', () => {
    it('makes expected calls', () => {
      expect(PerfilPage.prototype.cargarAvatar).toHaveBeenCalled();
    });
  });

  describe('cargarAvatar', () => {
    it('makes expected calls', () => {
      const routerStub: Router = fixture.debugElement.injector.get(Router);
      const avatarServiceStub: AvatarService = fixture.debugElement.injector.get(
        AvatarService
      );
      const storageServiceStub: StorageService = fixture.debugElement.injector.get(
        StorageService
      );
      spyOn(routerStub, 'navigateByUrl').and.callThrough();
      spyOn(avatarServiceStub, 'getUserProfile').and.callThrough();
      spyOn(storageServiceStub, 'set').and.callThrough();
      (<jasmine.Spy>component.cargarAvatar).and.callThrough();
      component.cargarAvatar();
      expect(routerStub.navigateByUrl).toHaveBeenCalled();
      expect(avatarServiceStub.getUserProfile).toHaveBeenCalled();
      expect(storageServiceStub.set).toHaveBeenCalled();
    });
  });

  describe('uploadAvatar', () => {
    it('makes expected calls', () => {
      const loadingControllerStub: LoadingController = fixture.debugElement.injector.get(
        LoadingController
      );
      const avatarServiceStub: AvatarService = fixture.debugElement.injector.get(
        AvatarService
      );
      spyOn(component, 'alertPresent').and.callThrough();
      spyOn(loadingControllerStub, 'create').and.callThrough();
      spyOn(avatarServiceStub, 'uploadAvatar').and.callThrough();
      component.uploadAvatar();
      expect(component.alertPresent).toHaveBeenCalled();
      expect(loadingControllerStub.create).toHaveBeenCalled();
      expect(avatarServiceStub.uploadAvatar).toHaveBeenCalled();
    });
  });
});
