import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { AlertController, LoadingController } from '@ionic/angular';
import { AuthService } from 'src/app/services/AuthServices/auth.service';
import { AvatarService } from 'src/app/services/AvatarServices/avatar.service';
import { StorageService } from 'src/app/services/StorageServices/storage.service';

// API para comunicar la aplicación con la camara.
import { Camera } from '@capacitor/camera';
import { CameraResultType, CameraSource } from '@capacitor/camera/dist/esm/definitions';

@Component({
	selector: 'app-perfil',
	templateUrl: './perfil.page.html',
	styleUrls: ['./perfil.page.scss'],
})

export class PerfilPage implements OnInit {
	// Variables para guardar la información de la foto de perfil y los valores del formulario.
	profile: any = null;
	sName: string;
	sLast: string;
	sEmail: string;
	sType: string;
	sImageUrl: string;
	sComuna: string;

	// Constructor
	constructor(
		private authService: AuthService,
		private avatarService: AvatarService,
		private alertCtrl: AlertController,
		private loadingCtrl: LoadingController,
		private storageService: StorageService,
		private router: Router,
	) {
		this.cargarAvatar();
	}

	async ngOnInit() {
		// Capturamos la información del usuario.
		this.sName = await this.storageService.get('names');
		this.sLast = await this.storageService.get('lastnames');
		this.sEmail = await this.storageService.get('email');
		this.sType = await this.storageService.get('typeAccount');
		this.sImageUrl = await this.storageService.get('imageUrl');
		this.sComuna = await this.storageService.get('comuna');
	}

	cargarAvatar() {
		this.avatarService.getUserProfile().subscribe(respuesta => {
			if (!this.sName) {
				this.storageService.set('names', respuesta.names);
				this.storageService.set('lastnames', respuesta.lastnames);
				this.storageService.set('typeAccount', respuesta.typeAccount);
				this.storageService.set('imageUrl', respuesta.imageUrl);
				this.storageService.set('comuna', respuesta.comuna);
				this.router.navigateByUrl('/perfil');
			}
			this.profile = respuesta;
		});
	}

	async uploadAvatar() {
		// Función para abrir la camara o galería para escoger una foto.
		const avatar = await Camera.getPhoto({
			quality: 90,
			allowEditing: false,
			resultType: CameraResultType.Base64,
			source: CameraSource.Camera
		});

		// 
		if (avatar) {
			const loading = await this.loadingCtrl.create();
			await loading.present();
			const result = await this.avatarService.uploadAvatar(avatar);
			loading.dismiss();

			if (!result) {
				this.alertPresent('Carga avatar fállida', 'Se ha producido un error, inténtelo más rato.');
			} else {
				this.sImageUrl = result;
			}
		}
	}

	async alertPresent(header: string, message: string) {
		const alert = await this.alertCtrl.create({
			header: header,
			message: message,
			buttons: ['OK']
		});
		await alert.present();
	}
}