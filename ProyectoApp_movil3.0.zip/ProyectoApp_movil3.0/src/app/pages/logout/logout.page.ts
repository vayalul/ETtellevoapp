import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { AlertController, LoadingController } from '@ionic/angular';
import { AuthService } from 'src/app/services/AuthServices/auth.service';
import { StorageService } from 'src/app/services/StorageServices/storage.service';

@Component({
	selector: 'app-logout',
	templateUrl: './logout.page.html',
	styleUrls: ['./logout.page.scss'],
})
export class LogoutPage implements OnInit {
	// Constructor
	constructor(
		private storageService: StorageService,
		private authService: AuthService,
		private alertCtrl: AlertController,
		private loadingCtrl: LoadingController,
		private router: Router
	) { }

	ngOnInit() { }

	// Función para cerra sesión en la aplicación.
	async logout() {
		// Creamos una pequeña ventana de carga mientras se realiza la consulta a la base de datos.
		const loading = await this.loadingCtrl.create();
		await loading.present();

		// Se realiza la consulta a Firebase para realizar.
		const user = await this.authService.logout();
		// Oculta la venta de carga una vez termine de ejecturarse la consulta a la base de datos.
		await loading.dismiss();

		// Eliminamos los elementos del storage.
		this.storageService.remove('imageUrl');
		this.storageService.remove('names');
		this.storageService.remove('lastnames');
		this.storageService.remove('email');
		this.storageService.remove('typeAccount');

		// Envía mensaje de exito y procede a redireccionar al inicio.
		this.alertPresent('Sesión cerrada', 'La sesión fue cerrada exitosamente');
		this.router.navigateByUrl('/inicio');
	}

	// Mensaje de alerta personalizado.
	async alertPresent(header: string, message: string) {
		const alert = await this.alertCtrl.create({
			header: header,
			message: message,
			buttons: ['OK'],
		});
		alert.present();
	}
}
