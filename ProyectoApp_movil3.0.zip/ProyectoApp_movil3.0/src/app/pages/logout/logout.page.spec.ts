import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { LoadingController } from '@ionic/angular';
import { AuthService } from 'src/app/services/AuthServices/auth.service';
import { StorageService } from 'src/app/services/StorageServices/storage.service';
import { LogoutPage } from './logout.page';

describe('LogoutPage', () => {
  let component: LogoutPage;
  let fixture: ComponentFixture<LogoutPage>;

  beforeEach(() => {
    const routerStub = () => ({ navigateByUrl: string => ({}) });
    const alertControllerStub = () => ({
      create: object => ({ present: () => ({}) })
    });
    const loadingControllerStub = () => ({
      create: () => ({ present: () => ({}), dismiss: () => ({}) })
    });
    const authServiceStub = () => ({ logout: () => ({}) });
    const storageServiceStub = () => ({ remove: string => ({}) });
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [LogoutPage],
      providers: [
        { provide: Router, useFactory: routerStub },
        { provide: AlertController, useFactory: alertControllerStub },
        { provide: LoadingController, useFactory: loadingControllerStub },
        { provide: AuthService, useFactory: authServiceStub },
        { provide: StorageService, useFactory: storageServiceStub }
      ]
    });
    fixture = TestBed.createComponent(LogoutPage);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  describe('logout', () => {
    it('makes expected calls', () => {
      const routerStub: Router = fixture.debugElement.injector.get(Router);
      const loadingControllerStub: LoadingController = fixture.debugElement.injector.get(
        LoadingController
      );
      const authServiceStub: AuthService = fixture.debugElement.injector.get(
        AuthService
      );
      const storageServiceStub: StorageService = fixture.debugElement.injector.get(
        StorageService
      );
      spyOn(component, 'alertPresent').and.callThrough();
      spyOn(routerStub, 'navigateByUrl').and.callThrough();
      spyOn(loadingControllerStub, 'create').and.callThrough();
      spyOn(authServiceStub, 'logout').and.callThrough();
      spyOn(storageServiceStub, 'remove').and.callThrough();
      component.logout();
      expect(component.alertPresent).toHaveBeenCalled();
      expect(routerStub.navigateByUrl).toHaveBeenCalled();
      expect(loadingControllerStub.create).toHaveBeenCalled();
      expect(authServiceStub.logout).toHaveBeenCalled();
      expect(storageServiceStub.remove).toHaveBeenCalled();
    });
  });
});
