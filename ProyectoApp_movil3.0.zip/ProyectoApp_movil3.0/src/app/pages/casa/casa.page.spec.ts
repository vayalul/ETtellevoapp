import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { LoadingController } from '@ionic/angular';
import { AuthService } from 'src/app/services/AuthServices/auth.service';
import { AvatarService } from 'src/app/services/AvatarServices/avatar.service';
import { StorageService } from 'src/app/services/StorageServices/storage.service';
import { RouterTestingModule } from '@angular/router/testing';
import { CasaPage } from './casa.page';

describe('CasaPage', () => {
  let component: CasaPage;
  let fixture: ComponentFixture<CasaPage>;

  beforeEach(() => {
    const routerStub = () => ({ navigateByUrl: (string, object) => ({}) });
    const alertControllerStub = () => ({
      create: object => ({ present: () => ({}) })
    });
    const loadingControllerStub = () => ({
      create: () => ({ present: () => ({}), dismiss: () => ({}) })
    });
    const authServiceStub = () => ({ logout: () => ({}) });
    const avatarServiceStub = () => ({
      getUserProfile: () => ({ subscribe: f => f({}) }),
      uploadAvatar: avatar => ({})
    });
    const storageServiceStub = () => ({ get: string => ({}) });
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule],
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [CasaPage],
      providers: [
        { provide: Router, useFactory: routerStub },
        { provide: AlertController, useFactory: alertControllerStub },
        { provide: LoadingController, useFactory: loadingControllerStub },
        { provide: AuthService, useFactory: authServiceStub },
        { provide: AvatarService, useFactory: avatarServiceStub },
        { provide: StorageService, useFactory: storageServiceStub }
      ]
    });
    spyOn(CasaPage.prototype, 'cargarAvatar');
    fixture = TestBed.createComponent(CasaPage);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  describe('constructor', () => {
    it('makes expected calls', () => {
      expect(CasaPage.prototype.cargarAvatar).toHaveBeenCalled();
    });
  });

  describe('logout', () => {
    it('makes expected calls', () => {
      const routerStub: Router = fixture.debugElement.injector.get(Router);
      const authServiceStub: AuthService = fixture.debugElement.injector.get(
        AuthService
      );
      spyOn(routerStub, 'navigateByUrl').and.callThrough();
      spyOn(authServiceStub, 'logout').and.callThrough();
      component.logout();
      expect(routerStub.navigateByUrl).toHaveBeenCalled();
      expect(authServiceStub.logout).toHaveBeenCalled();
    });
  });

  describe('cargarAvatar', () => {
    it('makes expected calls', () => {
      const avatarServiceStub: AvatarService = fixture.debugElement.injector.get(
        AvatarService
      );
      spyOn(avatarServiceStub, 'getUserProfile').and.callThrough();
      (<jasmine.Spy>component.cargarAvatar).and.callThrough();
      component.cargarAvatar();
      expect(avatarServiceStub.getUserProfile).toHaveBeenCalled();
    });
  });

  describe('uploadAvatar', () => {
    it('makes expected calls', () => {
      const loadingControllerStub: LoadingController = fixture.debugElement.injector.get(
        LoadingController
      );
      const avatarServiceStub: AvatarService = fixture.debugElement.injector.get(
        AvatarService
      );
      spyOn(component, 'alertPresent').and.callThrough();
      spyOn(loadingControllerStub, 'create').and.callThrough();
      spyOn(avatarServiceStub, 'uploadAvatar').and.callThrough();
      component.uploadAvatar();
      expect(component.alertPresent).toHaveBeenCalled();
      expect(loadingControllerStub.create).toHaveBeenCalled();
      expect(avatarServiceStub.uploadAvatar).toHaveBeenCalled();
    });
  });

  describe('loadData', () => {
    it('makes expected calls', () => {
      const httpTestingController = TestBed.inject(HttpTestingController);
      component.loadData().subscribe(res => {
        expect(res).toEqual();
      });
      const req = httpTestingController.expectOne('HTTP_ROUTE_GOES_HERE');
      expect(req.request.method).toEqual('GET');
      req.flush();
      httpTestingController.verify();
    });
  });
});
