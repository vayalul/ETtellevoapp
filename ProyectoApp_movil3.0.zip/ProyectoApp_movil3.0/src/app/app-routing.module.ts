import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { redirectUnauthorizedTo, redirectLoggedInTo, canActivate } from '@angular/fire/auth-guard';

const routes: Routes = [
	{
		path: '',
		redirectTo: 'home',
		pathMatch: 'full'
	},
	{
		path: 'home',
		loadChildren: () => import('./pages/home/home.module').then(m => m.HomePageModule),
		...canActivate(() => redirectLoggedInTo(['cerrar']))
	},
	{
		path: 'nosotros',
		loadChildren: () => import('./pages/about/about.module').then(m => m.AboutPageModule)
	},
	{
		path: 'perfil',
		loadChildren: () => import('./pages/perfil/perfil.module').then(m => m.PerfilPageModule),
		...canActivate(() => redirectUnauthorizedTo(['home']))
	},
	{
		path: 'contacto',
		loadChildren: () => import('./pages/contact/contact.module').then(m => m.ContactPageModule)
	},
	{
		path: 'conversor',
		loadChildren: () => import('./pages/conversor/conversor.module').then(m => m.ConversorPageModule),
	},
	{
		path: 'inicio',
		loadChildren: () => import('./pages/casa/casa.module').then(m => m.CasaPageModule)
	},
	{
		path: 'clima',
		loadChildren: () => import('./pages/clima/clima.module').then(m => m.ClimaPageModule)
	},
	{
		path: '404',
		loadChildren: () => import('./pages/page404/page404.module').then(m => m.Page404PageModule)
	},
	{
		path: 'registrarse',
		loadChildren: () => import('./pages/registrarse/registrarse.module').then(m => m.RegistrarsePageModule),
		...canActivate(() => redirectLoggedInTo(['cerrar']))
	},
	{
		path: 'iniciar',
		loadChildren: () => import('./pages/login/login.module').then(m => m.LoginPageModule),
		...canActivate(() => redirectLoggedInTo(['cerrar']))
	},
	{
		path: 'cerrar',
		loadChildren: () => import('./pages/logout/logout.module').then(m => m.LogoutPageModule),
		...canActivate(() => redirectUnauthorizedTo(['home']))
	},
	{
		path: 'viajes',
		loadChildren: () => import('./pages/viajes/viajes.module').then( m => m.ViajesPageModule),
		...canActivate(() => redirectUnauthorizedTo(['home']))
	},
  {
    path: 'nuevo-viaje',
    loadChildren: () => import('./pages/nuevo-viaje/nuevo-viaje.module').then( m => m.NuevoViajePageModule),
		...canActivate(() => redirectUnauthorizedTo(['home'])),
	},
	{
		path: '**',
		redirectTo: '404'
	},
];

@NgModule({
	imports: [RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules, onSameUrlNavigation: 'reload' })],
	exports: [RouterModule]
})

export class AppRoutingModule { }