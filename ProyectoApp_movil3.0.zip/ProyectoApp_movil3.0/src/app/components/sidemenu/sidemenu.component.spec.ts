import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { SidemenuComponent } from './sidemenu.component';

describe('SidemenuComponent', () => {
  let component: SidemenuComponent;
  let fixture: ComponentFixture<SidemenuComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [SidemenuComponent]
    });
    fixture = TestBed.createComponent(SidemenuComponent);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  it(`appPages has default value`, () => {
    expect(component.appPages).toEqual([, , , , ,]);
  });

  it(`labels has default value`, () => {
    expect(component.labels).toEqual([
      `Family`,
      `Friends`,
      `Notes`,
      `Work`,
      `Travel`,
      `Reminders`
    ]);
  });
});
